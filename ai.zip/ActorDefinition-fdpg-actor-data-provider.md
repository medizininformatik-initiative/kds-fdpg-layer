# FDPG Datenlieferant - FDPG KDS Obligations Layer v2026.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FDPG Datenlieferant**

## ActorDefinition: FDPG Datenlieferant 

| | |
| :--- | :--- |
| *Official URL*:https://forschen-fuer-gesundheit.de/fhir/fdpg-obligations/ActorDefinition/fdpg-actor-data-provider | *Version*:2026.0.0 |
| Active as of 2026-02-19 | *Computable Name*:FDPGDataProvider |
| *Other Identifiers:*https://forschen-fuer-gesundheit.de/fhir/fdpg-obligations#data-provider | |

 
Systeme die Daten an das FDPG liefern 

