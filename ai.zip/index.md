# Home - FDPG KDS Obligations Layer v2026.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://forschen-fuer-gesundheit.de/fhir/fdpg-obligations/ImplementationGuide/fdpg-kds-obligations | *Version*:2026.0.0 |
| Active as of 2026-02-19 | *Computable Name*:FDPGKDSObligations |

# FDPG KDS Obligations Layer

**Experimenteller Status** — Dieses Projekt befindet sich in der Prototyp-Phase und ist nicht für den produktiven Einsatz vorgesehen.

Die FDPG KDS Obligations Layer beschreibt, welche MustSupport-Elemente der MII-Kerndatensatz-Profile im **FDPG-Portal** (als Metadata Consumer) dargestellt werden. Die hier definierten Obligations und Datenkataloge dienen als Arbeitsgrundlage und können sich jederzeit ändern.

**Aktueller Fokus:** FDPG-Portal als einziger Actor (Metadata Consumer). Weitere Interfaces (z.B. DIZ-Systeme, TORCH) können in späteren Versionen ergänzt werden. Die Data-Population-Logik zwischen KDS und DIZ ist nicht Bestandteil dieser Spezifikation.

Siehe [Changelog](changelog.md) für die Versionshistorie.

## Übersicht

Die FDPG KDS Obligations Layer definiert FDPG-spezifische Anforderungen für die MII Kerndatensatz Profile.

### Motivation

Die MII KDS-Module werden von verschiedenen Arbeitsgruppen gepflegt. Eine zentrale Harmonisierung der FDPG-spezifischen Anforderungen direkt in den Modulen ist:

* Organisatorisch aufwändig (21+ Repositories, verschiedene Maintainer)
* Versionierungstechnisch komplex
* Schwer konsistent zu halten

**Lösung:** Ein separates "Overlay-Repository" das:

1. Alle KDS-Module als Dependencies importiert
1. FDPG-spezifische**Obligations**definiert
1. Konsolidierte**CapabilityStatements**bereitstellt
1. **ActorDefinitions**für Datenlieferanten und -konsumenten definiert
1. Keine Änderungen an den Original-Modulen erfordert

## Architektur

```
┌─────────────────────────────────────────────────────────────┐
│                      FDPG Data Consumer                      │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    fdpg-kds-obligations                      │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ Obligations │  │CapabilityS. │  │  ActorDefinitions   │  │
│  │  (SHOULD,   │  │(consolidated)│  │  - DataProvider     │  │
│  │   SHALL)    │  │             │  │  - DataConsumer     │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
          ┌───────────────────┼───────────────────┐
          ▼                   ▼                   ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│   KDS Person    │ │  KDS Diagnose   │ │    KDS Labor    │
│   (Original)    │ │   (Original)    │ │   (Original)    │
└─────────────────┘ └─────────────────┘ └─────────────────┘

```

## Module Coverage

Diese Layer deckt 16 MII Kerndatensatz Module mit insgesamt 244 Profilen ab (1 weiteres Modul ist ausstehend):

| | | | |
| :--- | :--- | :--- | :--- |
| [Person](modul-person.md) | 4 | base 2026.0.0 | Aktiv |
| [Diagnose](modul-diagnose.md) | 1 | base 2026.0.0 | Aktiv |
| [Prozedur](modul-prozedur.md) | 1 | base 2026.0.0 | Aktiv |
| [Fall](modul-fall.md) | 1 | base 2026.0.0 | Aktiv |
| [Laborbefund](modul-labor.md) | 3 | laborbefund 2026.0.1 | Aktiv |
| [Medikation](modul-medikation.md) | 5 | medikation 2026.0.0 | Aktiv |
| [Biobank](modul-biobank.md) | 11 | biobank 2026.0.0 | Aktiv |
| [Studie](modul-studie.md) | 7 | studie 2026.0.2 | Aktiv |
| [Molekulargenetik](modul-molgen.md) | 16 | molgen 2026.0.4 | Aktiv |
| [Pathologiebefund](modul-patho.md) | 17 | patho 2026.0.1 | Aktiv |
| [Intensivmedizin](modul-icu.md) | 72 | icu 2026.0.1-rc1 | Aktiv |
| [Bildgebung](modul-bildgebung.md) | 11 | bildgebung 2026.0.0 | Aktiv |
| [Seltene Erkrankungen](modul-seltene.md) | 18 | seltene 2026.0.0 | Aktiv |
| [Onkologie](modul-onkologie.md) | 73 | onkologie 2026.0.1 | Aktiv |
| [Einwilligung](modul-consent.md) | 3 | consent 2026.0.1-rc-1 | Aktiv |
| [Dokument](modul-dokument.md) | 1 | dokument 2026.0.0 | Aktiv |
| [Symptom](modul-symptom.md) | – | symptom 2026.0.0 | Ausstehend |
| **Gesamt** | **244** |   |   |

## Verwendung

```
dependencies:
  fdpg-kds-obligations: 2026.0.0

```

## Referenzen

* [FHIR Obligations Extension](http://hl7.org/fhir/extensions/5.1.0/StructureDefinition-obligation.html)
* [MII Kerndatensatz](https://www.medizininformatik-initiative.de/de/basismodule-des-kerndatensatzes-der-mii)
* [FDPG Portal](https://forschen-fuer-gesundheit.de)

