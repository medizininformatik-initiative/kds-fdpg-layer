# FDPG Datenlieferant - XML Representation - FDPG KDS Obligations Layer v2026.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FDPG Datenlieferant**

## : FDPG Datenlieferant - XML Representation

| |
| :--- |
| Active as of 2026-02-19 |

[Raw xml](ActorDefinition-fdpg-actor-data-provider.xml) | [Download](ActorDefinition-fdpg-actor-data-provider.xml)

