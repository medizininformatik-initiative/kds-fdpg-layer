# FDPG Datenkonsument - XML Representation - FDPG KDS Obligations Layer v2026.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FDPG Datenkonsument**

## : FDPG Datenkonsument - XML Representation

| |
| :--- |
| Active as of 2026-02-19 |

[Raw xml](ActorDefinition-fdpg-actor-data-consumer.xml) | [Download](ActorDefinition-fdpg-actor-data-consumer.xml)

