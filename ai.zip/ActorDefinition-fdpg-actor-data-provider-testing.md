# FDPG Datenlieferant - Testing - FDPG KDS Obligations Layer v2026.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FDPG Datenlieferant**

## ActorDefinition: FDPG Datenlieferant - Testing 

| |
| :--- |
| Active as of 2026-02-19 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

