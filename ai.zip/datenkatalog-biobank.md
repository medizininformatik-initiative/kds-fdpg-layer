# Datenkatalog Biobank - FDPG KDS Obligations Layer v2026.0.0

* [**Table of Contents**](toc.md)
* **Datenkatalog Biobank**

## Datenkatalog Biobank

# Datenkatalog Biobank

Diese Seite listet alle MustSupport-Elemente der MII-Elternprofile mit deutschen und englischen Beschreibungen. Die Obligations werden auf der Seite [Obligations](obligations.md) beschrieben.

**Quellpaket:** [de.medizininformatikinitiative.kerndatensatz.biobank](https://simplifier.net/packages/de.medizininformatikinitiative.kerndatensatz.biobank/2026.0.0)

#### Observation DNA Konzentration (Observation)

**FDPG Profil:** [FDPG_PR_Biobank_Observation_DNA_Konzentration](StructureDefinition-fdpg-pr-biobank-observation-dna-konzentration.md) · **MII Elternprofil:** MII_PR_Biobank_Observation_DNA_Konzentration

| | | |
| :--- | :--- | :--- |
| `id` | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `code` | Type of observation (code / type) | Describes what was observed. Sometimes this is called the observation "name". |
| `focus` | What the observation is about, when it is not about the subject of record | The actual focus of an observation when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, fetus, or donor. For example, fetus o… |
| `effective[x]` | Clinically relevant time/time-period for observation | The time or time-period the observed value is asserted as being true. For biological subjects - e.g. human patients - this is usually called the "physiologically relevant time". This is usually eit… |
| `value[x]` | Actual result | The information determined as a result of making the observation, if the information has a simple value. |

#### Observation Karyotyp (Observation)

**FDPG Profil:** [FDPG_PR_Biobank_Observation_Karyotyp](StructureDefinition-fdpg-pr-biobank-observation-karyotyp.md) · **MII Elternprofil:** MII_PR_Biobank_Observation_Karyotyp

| | | |
| :--- | :--- | :--- |
| `id` | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `code` | Type of observation (code / type) | Describes what was observed. Sometimes this is called the observation "name". |
| `focus` | What the observation is about, when it is not about the subject of record | The actual focus of an observation when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, fetus, or donor. For example, fetus o… |
| `effective[x]` | Clinically relevant time/time-period for observation | The time or time-period the observed value is asserted as being true. For biological subjects - e.g. human patients - this is usually called the "physiologically relevant time". This is usually eit… |
| `value[x]` | Actual result | The information determined as a result of making the observation, if the information has a simple value. |

#### Observation Morphologie (Observation)

**FDPG Profil:** [FDPG_PR_Biobank_Observation_Morphologie](StructureDefinition-fdpg-pr-biobank-observation-morphologie.md) · **MII Elternprofil:** MII_PR_Biobank_Observation_Morphologie

| | | |
| :--- | :--- | :--- |
| `id` | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `code` | Type of observation (code / type) | Describes what was observed. Sometimes this is called the observation "name". |
| `focus` | What the observation is about, when it is not about the subject of record | The actual focus of an observation when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, fetus, or donor. For example, fetus o… |
| `value[x]` | Actual result | The information determined as a result of making the observation, if the information has a simple value. |

#### Observation Proliferation (Observation)

**FDPG Profil:** [FDPG_PR_Biobank_Observation_Proliferation](StructureDefinition-fdpg-pr-biobank-observation-proliferation.md) · **MII Elternprofil:** MII_PR_Biobank_Observation_Proliferation

| | | |
| :--- | :--- | :--- |
| `id` | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `code` | Type of observation (code / type) | Describes what was observed. Sometimes this is called the observation "name". |
| `focus` | What the observation is about, when it is not about the subject of record | The actual focus of an observation when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, fetus, or donor. For example, fetus o… |
| `value[x]` | Actual result | The information determined as a result of making the observation, if the information has a simple value. |

#### Observation Qualitätsprüfung (Observation)

**FDPG Profil:** [FDPG_PR_Biobank_Observation_Qualitaetspruefung](StructureDefinition-fdpg-pr-biobank-observation-qualitaetspruefung.md) · **MII Elternprofil:** MII_PR_Biobank_Observation_Qualitaetspruefung

| | | |
| :--- | :--- | :--- |
| `id` | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `code` | Type of observation (code / type) | Describes what was observed. Sometimes this is called the observation "name". |
| `focus` | What the observation is about, when it is not about the subject of record | The actual focus of an observation when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, fetus, or donor. For example, fetus o… |
| `effective[x]` | Clinically relevant time/time-period for observation | The time or time-period the observed value is asserted as being true. For biological subjects - e.g. human patients - this is usually called the "physiologically relevant time". This is usually eit… |
| `component:type` | Component results | Some observations have multiple component observations. These component observations are expressed as separate code value pairs that share the same attributes. Examples include systolic and diastol… |
| `component:result` | Component results | Some observations have multiple component observations. These component observations are expressed as separate code value pairs that share the same attributes. Examples include systolic and diastol… |

#### Observation Wachstumstyp (Observation)

**FDPG Profil:** [FDPG_PR_Biobank_Observation_Wachstumstyp](StructureDefinition-fdpg-pr-biobank-observation-wachstumstyp.md) · **MII Elternprofil:** MII_PR_Biobank_Observation_Wachstumstyp

| | | |
| :--- | :--- | :--- |
| `id` | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `code` | Type of observation (code / type) | Describes what was observed. Sometimes this is called the observation "name". |
| `focus` | What the observation is about, when it is not about the subject of record | The actual focus of an observation when it is not the patient of record representing something or someone associated with the patient such as a spouse, parent, fetus, or donor. For example, fetus o… |
| `value[x]` | Actual result | The information determined as a result of making the observation, if the information has a simple value. |

#### Organization Sammlung Biobank (Organization)

**FDPG Profil:** [FDPG_PR_Biobank_Organization_Sammlung_Biobank](StructureDefinition-fdpg-pr-biobank-organization.md) · **MII Elternprofil:** MII_PR_Biobank_Organization_Sammlung_Biobank

| | | |
| :--- | :--- | :--- |
| `id` | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `extension:beschreibung` | Beschreibung der Sammlung/Biobank | Eine Freitextbeschreibung der Sammlung/Biobank, die z.B. in einer Suche angezeigt werden kann. |
| `extension:collectionSetting` | Sample Collection Setting Extension | The context in which the sample collection was/is conducted. |
| `extension:collectionDesign` | Collection Design Extension | The overall design of the collection that explains how the collection was/is built up. |
| `identifier` | Identifies this organization across multiple systems | Identifier for the organization that is used to identify the organization across multiple disparate systems. |
| `identifier:bbmri-eric-id` | BBMRI-ERIC ID | Eindeutige Kennung im BBMRI-ERIC-Netzwerk. |
| `name` | Name | Der vollständige Name der Sammlung oder Biobank. |
| `alias` | Akronym | Das Akronym oder der Kurztitel der Sammlung oder Biobank. |
| `partOf` | Teil von | Verweist auf eine übergeordnete Sammlung oder Biobank, zu der diese gehört. |
| `contact` | Contact for the organization for a certain purpose | Contact for the organization for a certain purpose. |
| `contact:forschungskontakt` | Contact for the organization for a certain purpose | Contact for the organization for a certain purpose. |

#### Specimen Bioprobe Core (Specimen)

**FDPG Profil:** [FDPG_PR_Biobank_Specimen_Bioprobe_Core](StructureDefinition-fdpg-pr-biobank-specimen-core.md) · **MII Elternprofil:** MII_PR_Biobank_Specimen_Bioprobe_Core

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| `id` |   |   | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` |   |   | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` |   |   | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` |   |   | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `extension:probenebene` |   |   | MII EX Biobank Ebene | Mittels dieser Extension kann ausgedrückt werden, welcher Probenebene dieses Specimen zuzuordnen ist. |
| `identifier` | Proben-ID | Einrichtungsinterner Identifier der Probe | Proben-ID | Einrichtungsinterner Identifier der Probe. |
| `status` | Verfuegbarkeitsstatus | Status der Probe / des Materials hinsichtlich der Verfügbarkeit | Verfügbarkeitsstatus | Der Status der Probe in Bezug auf die Verfügbarkeit für Forschung. |
| `type` | Probenart | Art der Probe; SCT verpflichtend; Beschränkung auf Specimen ValueSet erwünscht. | Probenart | Die Art der Probe, codiert in SNOMED CT. |
| `subject` |   |   | Patient:in | Verweis auf die Person, von der die Probe stammt. |
| `receivedTime` |   |   | The time when specimen was received for processing | Time when specimen was received for processing or testing. |
| `parent` | Entstanden-aus | Referenz auf Bioprobe | Ist gewonnen aus | Referenz auf eine übergeordnete Probe, aus der diese Probe gewonnen wurde. |
| `request` |   |   | Entnahme-ID | Der Identifier der Probenentnahme. |
| `collection` | Probenentnahme | Informationen zur Entnahme der Probe | Probenentnahme | Informationen über den Prozess der Probenentnahme, einschließlich Entnahmezeitpunkt und -stelle. |
| `processing` | Verarbeitungsprozess | Prozedur der Probenbearbeitung | Probenverarbeitung | Details zur Verarbeitung der Probe, einschließlich Prozeduren und Verarbeitungszeitraum. |
| `processing:lagerprozess` | Verarbeitungsprozess | Prozedur der Probenbearbeitung | Processing and processing step details | Details concerning processing and processing steps for the specimen. |
| `container` | Container | Probenbehältnis | Probenbehältnis | Informationen über den Behälter, in dem die Probe aufbewahrt wird. |
| `note` | Projektverwendung, SonstigeEigenschaften | Freitextangabe zur Verwendung der Probe in Projekten | Projektnutzung | Freitextangabe zur Verwendung der Probe in spezifischen Projekten. |

#### Specimen Bioprobe (Specimen)

**FDPG Profil:** [FDPG_PR_Biobank_Specimen_Bioprobe](StructureDefinition-fdpg-pr-biobank-specimen.md) · **MII Elternprofil:** MII_PR_Biobank_Specimen_Bioprobe

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| `id` |   |   | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` |   |   | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` |   |   | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` |   |   | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `extension:probenebene` |   |   | MII EX Biobank Ebene | Mittels dieser Extension kann ausgedrückt werden, welcher Probenebene dieses Specimen zuzuordnen ist. |
| `extension:festgestellteDiagnose` |   |   | Festgestellte Diagnose | Verweis auf eine Diagnose, für die Material in der Probe enthalten ist. |
| `extension:gehoertZu` |   |   | Verwaltende Organisation | Zuordnung der Probe zu einer Sammlung oder Biobank, die für die Verwaltung verantwortlich ist. |
| `extension:anzahlAliquots` |   |   | MII EX Biobank Anzahl Aliquots | Die Extension ermöglicht es, die Anzahl der vorhandenen Aliquots zu einer Aliquot-Gruppe anzugeben. |
| `identifier` | Proben-ID | Einrichtungsinterner Identifier der Probe | Proben-ID | Einrichtungsinterner Identifier der Probe. |
| `status` | Verfuegbarkeitsstatus | Status der Probe / des Materials hinsichtlich der Verfügbarkeit | Verfügbarkeitsstatus | Der Status der Probe in Bezug auf die Verfügbarkeit für Forschung. |
| `type` | Probenart | Art der Probe; SCT verpflichtend; Beschränkung auf Specimen ValueSet erwünscht. | Probenart | Die Art der Probe, codiert in SNOMED CT. |
| `subject` |   |   | Patient:in | Verweis auf die Person, von der die Probe stammt. |
| `receivedTime` |   |   | The time when specimen was received for processing | Time when specimen was received for processing or testing. |
| `parent` | Entstanden-aus | Referenz auf Bioprobe | Ist gewonnen aus | Referenz auf eine übergeordnete Probe, aus der diese Probe gewonnen wurde. |
| `request` |   |   | Entnahme-ID | Der Identifier der Probenentnahme. |
| `collection` | Probenentnahme | Informationen zur Entnahme der Probe | Probenentnahme | Informationen über den Prozess der Probenentnahme, einschließlich Entnahmezeitpunkt und -stelle. |
| `processing` | Verarbeitungsprozess | Prozedur der Probenbearbeitung | Probenverarbeitung | Details zur Verarbeitung der Probe, einschließlich Prozeduren und Verarbeitungszeitraum. |
| `processing:lagerprozess` | Verarbeitungsprozess | Prozedur der Probenbearbeitung | Processing and processing step details | Details concerning processing and processing steps for the specimen. |
| `container` | Container | Probenbehältnis | Probenbehältnis | Informationen über den Behälter, in dem die Probe aufbewahrt wird. |
| `note` | Projektverwendung, SonstigeEigenschaften | Freitextangabe zur Verwendung der Probe in Projekten | Projektnutzung | Freitextangabe zur Verwendung der Probe in spezifischen Projekten. |

#### Substance Additiv (Substance)

**FDPG Profil:** [FDPG_PR_Biobank_Substance_Additiv](StructureDefinition-fdpg-pr-biobank-substance-additiv.md) · **MII Elternprofil:** MII_PR_Biobank_Substance_Additiv

| | | |
| :--- | :--- | :--- |
| `id` | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `category` | What class/type of substance this is | A code that classifies the general type of substance. This is used for searching, sorting and display purposes. |
| `code` | What substance this is | A code (or set of codes) that identify this substance. |
| `ingredient` | Composition information about the substance | A substance can be composed of other substances. |

#### Specimen Zellinie Organoid (Specimen)

**FDPG Profil:** [FDPG_PR_Biobank_Specimen_Zellinie_Organoid](StructureDefinition-fdpg-pr-biobank-zellinie-organoid.md) · **MII Elternprofil:** MII_PR_Biobank_Specimen_Zellinie_Organoid

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| `id` |   |   | Logical id of this artifact | The logical id of the resource, as used in the URL for the resource. Once assigned, this value never changes. |
| `meta` |   |   | Metadata about the resource | The metadata about the resource. This is content that is maintained by the infrastructure. Changes to the content might not always be associated with version changes to the resource. |
| `meta.source` |   |   | Identifies where the resource comes from | A uri that identifies the source system of the resource. This provides a minimal amount of[Provenance](provenance.md#)information that can be used to track or differentiate the source of inform… |
| `meta.profile` |   |   | Profiles this resource claims to conform to | A list of profiles (references to[StructureDefinition](structuredefinition.md#)resources) that this resource claims to conform to. The URL is a reference to [StructureDefinition.url](structured… |
| `extension:probenebene` |   |   | MII EX Biobank Ebene | Mittels dieser Extension kann ausgedrückt werden, welcher Probenebene dieses Specimen zuzuordnen ist. |
| `extension:festgestellteDiagnose` |   |   | Festgestellte Diagnose | Verweis auf eine Diagnose, für die Material in der Probe enthalten ist. |
| `extension:gehoertZu` |   |   | Verwaltende Organisation | Zuordnung der Probe zu einer Sammlung oder Biobank, die für die Verwaltung verantwortlich ist. |
| `extension:anzahlAliquots` |   |   | MII EX Biobank Anzahl Aliquots | Die Extension ermöglicht es, die Anzahl der vorhandenen Aliquots zu einer Aliquot-Gruppe anzugeben. |
| `extension:kulturprotokoll` |   |   | MII EX Biobank Kulturprotokoll | Protokoll der Kultur der Zellinie oder des Organiods. |
| `extension:modifikationen` |   |   | MII EX Biobank Zelllinien-Modifikation | Erweiterung zur Beschreibung von Modifikationen an Zelllinien, einschließlich Art der Modifikation, Zielgen und Referenz zum Protokoll. |
| `extension:anzahlPassagen` |   |   | MII EX Biobank Anzahl Passagen | Zahl der Passagen, die die Zellinie oder das Organiod durchlaufen hat. |
| `identifier` | Proben-ID | Einrichtungsinterner Identifier der Probe | Proben-ID | Einrichtungsinterner Identifier der Probe. |
| `status` | Verfuegbarkeitsstatus | Status der Probe / des Materials hinsichtlich der Verfügbarkeit | Verfügbarkeitsstatus | Der Status der Probe in Bezug auf die Verfügbarkeit für Forschung. |
| `type` | Probenart | Art der Probe; SCT verpflichtend; Beschränkung auf Specimen ValueSet erwünscht. | Probenart | Die Art der Probe, codiert in SNOMED CT. |
| `subject` |   |   | Patient:in | Verweis auf die Person, von der die Probe stammt. |
| `receivedTime` |   |   | The time when specimen was received for processing | Time when specimen was received for processing or testing. |
| `parent` | Entstanden-aus | Referenz auf Bioprobe | Ist gewonnen aus | Referenz auf eine übergeordnete Probe, aus der diese Probe gewonnen wurde. |
| `request` |   |   | Entnahme-ID | Der Identifier der Probenentnahme. |
| `collection` | Probenentnahme | Informationen zur Entnahme der Probe | Probenentnahme | Informationen über den Prozess der Probenentnahme, einschließlich Entnahmezeitpunkt und -stelle. |
| `processing` | Verarbeitungsprozess | Prozedur der Probenbearbeitung | Probenverarbeitung | Details zur Verarbeitung der Probe, einschließlich Prozeduren und Verarbeitungszeitraum. |
| `processing:lagerprozess` | Verarbeitungsprozess | Prozedur der Probenbearbeitung | Processing and processing step details | Details concerning processing and processing steps for the specimen. |
| `container` | Container | Probenbehältnis | Probenbehältnis | Informationen über den Behälter, in dem die Probe aufbewahrt wird. |
| `note` | Projektverwendung, SonstigeEigenschaften | Freitextangabe zur Verwendung der Probe in Projekten | Projektnutzung | Freitextangabe zur Verwendung der Probe in spezifischen Projekten. |

-------

## English Translations

