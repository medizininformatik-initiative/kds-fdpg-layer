# FDPG Datenkonsument - FDPG KDS Obligations Layer v2026.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FDPG Datenkonsument**

## ActorDefinition: FDPG Datenkonsument 

| | |
| :--- | :--- |
| *Official URL*:https://forschen-fuer-gesundheit.de/fhir/fdpg-obligations/ActorDefinition/fdpg-actor-data-consumer | *Version*:2026.0.0 |
| Active as of 2026-02-19 | *Computable Name*:FDPGDataConsumer |
| *Other Identifiers:*https://forschen-fuer-gesundheit.de/fhir/fdpg-obligations#data-consumer | |

 
Systeme die Daten vom FDPG abrufen 

