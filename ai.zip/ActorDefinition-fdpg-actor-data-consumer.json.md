# FDPG Datenkonsument - JSON Representation - FDPG KDS Obligations Layer v2026.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FDPG Datenkonsument**

## : FDPG Datenkonsument - JSON Representation

| |
| :--- |
| Active as of 2026-02-19 |

[Raw json](ActorDefinition-fdpg-actor-data-consumer.json) | [Download](ActorDefinition-fdpg-actor-data-consumer.json)

