#  - FDPG KDS Obligations Layer v2026.0.0

## : FDPGDataConsumer - Change History

History of changes for fdpg-actor-data-consumer .

