# Changelog - FDPG KDS Obligations Layer v2026.0.0

* [**Table of Contents**](toc.md)
* **Changelog**

## Changelog

# Changelog

| | | |
| :--- | :--- | :--- |
| 0.1.0 (Prototyp) | 2026-02 | Initiale experimentelle Version: Obligations, ActorDefinitions, Datenkatalog für 16 Module (244 Profile). Fokus: FDPG-Portal als Metadata Consumer. |

